import os
currentPath = os.path.dirname(os.path.abspath(__file__))
