LOCALEDIR = "/usr/share/locale"
PKGVERSION = "2.4.1"